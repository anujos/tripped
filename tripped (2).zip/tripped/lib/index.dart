// Export pages
export 'login/login_widget.dart' show LoginWidget;
export 'gmap/gmap_widget.dart' show GmapWidget;
export 'edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export 'forgotpassword/forgotpassword_widget.dart' show ForgotpasswordWidget;
export 'logout/logout_widget.dart' show LogoutWidget;
export 'place_details/place_details_widget.dart' show PlaceDetailsWidget;
export 'gmap_copy/gmap_copy_widget.dart' show GmapCopyWidget;
export 'home/home_widget.dart' show HomeWidget;
export 'places/places_widget.dart' show PlacesWidget;
export 'hotels/hotels_widget.dart' show HotelsWidget;
export 'shoppingmall/shoppingmall_widget.dart' show ShoppingmallWidget;
export 'restaurent/restaurent_widget.dart' show RestaurentWidget;
export 'waterfall/waterfall_widget.dart' show WaterfallWidget;
export 'amusement_park/amusement_park_widget.dart' show AmusementParkWidget;
export 'place_details_copy/place_details_copy_widget.dart'
    show PlaceDetailsCopyWidget;
export 'place_details_copy2/place_details_copy2_widget.dart'
    show PlaceDetailsCopy2Widget;
export 'hotels_copy/hotels_copy_widget.dart' show HotelsCopyWidget;
export 'varkal_rest/varkal_rest_widget.dart' show VarkalRestWidget;
export 'vagamon_rest/vagamon_rest_widget.dart' show VagamonRestWidget;
export 'kochi_resttt/kochi_resttt_widget.dart' show KochiRestttWidget;
export 'beaches/beaches_widget.dart' show BeachesWidget;
export 'searchpage/searchpage_widget.dart' show SearchpageWidget;
export 'description/description_widget.dart' show DescriptionWidget;
export 'menu/menu_widget.dart' show MenuWidget;

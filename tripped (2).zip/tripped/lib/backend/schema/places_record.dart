import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'places_record.g.dart';

abstract class PlacesRecord
    implements Built<PlacesRecord, PlacesRecordBuilder> {
  static Serializer<PlacesRecord> get serializer => _$placesRecordSerializer;

  @nullable
  @BuiltValueField(wireName: 'p_id')
  int get pId;

  @nullable
  @BuiltValueField(wireName: 'p_name')
  String get pName;

  @nullable
  String get description;

  @nullable
  @BuiltValueField(wireName: 'place_location')
  LatLng get placeLocation;

  @nullable
  String get photos;

  @nullable
  String get address;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(PlacesRecordBuilder builder) => builder
    ..pId = 0
    ..pName = ''
    ..description = ''
    ..photos = ''
    ..address = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('places');

  static Stream<PlacesRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<PlacesRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  PlacesRecord._();
  factory PlacesRecord([void Function(PlacesRecordBuilder) updates]) =
      _$PlacesRecord;

  static PlacesRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createPlacesRecordData({
  int pId,
  String pName,
  String description,
  LatLng placeLocation,
  String photos,
  String address,
}) =>
    serializers.toFirestore(
        PlacesRecord.serializer,
        PlacesRecord((p) => p
          ..pId = pId
          ..pName = pName
          ..description = description
          ..placeLocation = placeLocation
          ..photos = photos
          ..address = address));

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'places_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<PlacesRecord> _$placesRecordSerializer =
    new _$PlacesRecordSerializer();

class _$PlacesRecordSerializer implements StructuredSerializer<PlacesRecord> {
  @override
  final Iterable<Type> types = const [PlacesRecord, _$PlacesRecord];
  @override
  final String wireName = 'PlacesRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, PlacesRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.pId;
    if (value != null) {
      result
        ..add('p_id')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.pName;
    if (value != null) {
      result
        ..add('p_name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.description;
    if (value != null) {
      result
        ..add('description')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.placeLocation;
    if (value != null) {
      result
        ..add('place_location')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(LatLng)));
    }
    value = object.photos;
    if (value != null) {
      result
        ..add('photos')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  PlacesRecord deserialize(Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new PlacesRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'p_id':
          result.pId = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'p_name':
          result.pName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'description':
          result.description = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'place_location':
          result.placeLocation = serializers.deserialize(value,
              specifiedType: const FullType(LatLng)) as LatLng;
          break;
        case 'photos':
          result.photos = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$PlacesRecord extends PlacesRecord {
  @override
  final int pId;
  @override
  final String pName;
  @override
  final String description;
  @override
  final LatLng placeLocation;
  @override
  final String photos;
  @override
  final String address;
  @override
  final DocumentReference<Object> reference;

  factory _$PlacesRecord([void Function(PlacesRecordBuilder) updates]) =>
      (new PlacesRecordBuilder()..update(updates)).build();

  _$PlacesRecord._(
      {this.pId,
      this.pName,
      this.description,
      this.placeLocation,
      this.photos,
      this.address,
      this.reference})
      : super._();

  @override
  PlacesRecord rebuild(void Function(PlacesRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  PlacesRecordBuilder toBuilder() => new PlacesRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is PlacesRecord &&
        pId == other.pId &&
        pName == other.pName &&
        description == other.description &&
        placeLocation == other.placeLocation &&
        photos == other.photos &&
        address == other.address &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc($jc($jc(0, pId.hashCode), pName.hashCode),
                        description.hashCode),
                    placeLocation.hashCode),
                photos.hashCode),
            address.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('PlacesRecord')
          ..add('pId', pId)
          ..add('pName', pName)
          ..add('description', description)
          ..add('placeLocation', placeLocation)
          ..add('photos', photos)
          ..add('address', address)
          ..add('reference', reference))
        .toString();
  }
}

class PlacesRecordBuilder
    implements Builder<PlacesRecord, PlacesRecordBuilder> {
  _$PlacesRecord _$v;

  int _pId;
  int get pId => _$this._pId;
  set pId(int pId) => _$this._pId = pId;

  String _pName;
  String get pName => _$this._pName;
  set pName(String pName) => _$this._pName = pName;

  String _description;
  String get description => _$this._description;
  set description(String description) => _$this._description = description;

  LatLng _placeLocation;
  LatLng get placeLocation => _$this._placeLocation;
  set placeLocation(LatLng placeLocation) =>
      _$this._placeLocation = placeLocation;

  String _photos;
  String get photos => _$this._photos;
  set photos(String photos) => _$this._photos = photos;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  PlacesRecordBuilder() {
    PlacesRecord._initializeBuilder(this);
  }

  PlacesRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _pId = $v.pId;
      _pName = $v.pName;
      _description = $v.description;
      _placeLocation = $v.placeLocation;
      _photos = $v.photos;
      _address = $v.address;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(PlacesRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$PlacesRecord;
  }

  @override
  void update(void Function(PlacesRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$PlacesRecord build() {
    final _$result = _$v ??
        new _$PlacesRecord._(
            pId: pId,
            pName: pName,
            description: description,
            placeLocation: placeLocation,
            photos: photos,
            address: address,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new

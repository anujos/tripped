// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'hotels_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<HotelsRecord> _$hotelsRecordSerializer =
    new _$HotelsRecordSerializer();

class _$HotelsRecordSerializer implements StructuredSerializer<HotelsRecord> {
  @override
  final Iterable<Type> types = const [HotelsRecord, _$HotelsRecord];
  @override
  final String wireName = 'HotelsRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, HotelsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.hotelId;
    if (value != null) {
      result
        ..add('hotel_id')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.price;
    if (value != null) {
      result
        ..add('price')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.rating;
    if (value != null) {
      result
        ..add('rating')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.hotelName;
    if (value != null) {
      result
        ..add('hotel_name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.hotelLocation;
    if (value != null) {
      result
        ..add('hotel_location')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(LatLng)));
    }
    value = object.photo;
    if (value != null) {
      result
        ..add('photo')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  HotelsRecord deserialize(Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new HotelsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'hotel_id':
          result.hotelId = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'price':
          result.price = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'rating':
          result.rating = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'hotel_name':
          result.hotelName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'hotel_location':
          result.hotelLocation = serializers.deserialize(value,
              specifiedType: const FullType(LatLng)) as LatLng;
          break;
        case 'photo':
          result.photo = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$HotelsRecord extends HotelsRecord {
  @override
  final int hotelId;
  @override
  final int price;
  @override
  final int rating;
  @override
  final String hotelName;
  @override
  final LatLng hotelLocation;
  @override
  final String photo;
  @override
  final DocumentReference<Object> reference;

  factory _$HotelsRecord([void Function(HotelsRecordBuilder) updates]) =>
      (new HotelsRecordBuilder()..update(updates)).build();

  _$HotelsRecord._(
      {this.hotelId,
      this.price,
      this.rating,
      this.hotelName,
      this.hotelLocation,
      this.photo,
      this.reference})
      : super._();

  @override
  HotelsRecord rebuild(void Function(HotelsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  HotelsRecordBuilder toBuilder() => new HotelsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is HotelsRecord &&
        hotelId == other.hotelId &&
        price == other.price &&
        rating == other.rating &&
        hotelName == other.hotelName &&
        hotelLocation == other.hotelLocation &&
        photo == other.photo &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc($jc($jc(0, hotelId.hashCode), price.hashCode),
                        rating.hashCode),
                    hotelName.hashCode),
                hotelLocation.hashCode),
            photo.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('HotelsRecord')
          ..add('hotelId', hotelId)
          ..add('price', price)
          ..add('rating', rating)
          ..add('hotelName', hotelName)
          ..add('hotelLocation', hotelLocation)
          ..add('photo', photo)
          ..add('reference', reference))
        .toString();
  }
}

class HotelsRecordBuilder
    implements Builder<HotelsRecord, HotelsRecordBuilder> {
  _$HotelsRecord _$v;

  int _hotelId;
  int get hotelId => _$this._hotelId;
  set hotelId(int hotelId) => _$this._hotelId = hotelId;

  int _price;
  int get price => _$this._price;
  set price(int price) => _$this._price = price;

  int _rating;
  int get rating => _$this._rating;
  set rating(int rating) => _$this._rating = rating;

  String _hotelName;
  String get hotelName => _$this._hotelName;
  set hotelName(String hotelName) => _$this._hotelName = hotelName;

  LatLng _hotelLocation;
  LatLng get hotelLocation => _$this._hotelLocation;
  set hotelLocation(LatLng hotelLocation) =>
      _$this._hotelLocation = hotelLocation;

  String _photo;
  String get photo => _$this._photo;
  set photo(String photo) => _$this._photo = photo;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  HotelsRecordBuilder() {
    HotelsRecord._initializeBuilder(this);
  }

  HotelsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _hotelId = $v.hotelId;
      _price = $v.price;
      _rating = $v.rating;
      _hotelName = $v.hotelName;
      _hotelLocation = $v.hotelLocation;
      _photo = $v.photo;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(HotelsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$HotelsRecord;
  }

  @override
  void update(void Function(HotelsRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$HotelsRecord build() {
    final _$result = _$v ??
        new _$HotelsRecord._(
            hotelId: hotelId,
            price: price,
            rating: rating,
            hotelName: hotelName,
            hotelLocation: hotelLocation,
            photo: photo,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new

import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'restuarants_record.g.dart';

abstract class RestuarantsRecord
    implements Built<RestuarantsRecord, RestuarantsRecordBuilder> {
  static Serializer<RestuarantsRecord> get serializer =>
      _$restuarantsRecordSerializer;

  @nullable
  @BuiltValueField(wireName: 'rest_name')
  String get restName;

  @nullable
  @BuiltValueField(wireName: 'rest_id')
  int get restId;

  @nullable
  @BuiltValueField(wireName: 'rest_image')
  String get restImage;

  @nullable
  @BuiltValueField(wireName: 'rest_rating')
  int get restRating;

  @nullable
  @BuiltValueField(wireName: 'rest_location')
  LatLng get restLocation;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(RestuarantsRecordBuilder builder) => builder
    ..restName = ''
    ..restId = 0
    ..restImage = ''
    ..restRating = 0;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('restuarants');

  static Stream<RestuarantsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<RestuarantsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  RestuarantsRecord._();
  factory RestuarantsRecord([void Function(RestuarantsRecordBuilder) updates]) =
      _$RestuarantsRecord;

  static RestuarantsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createRestuarantsRecordData({
  String restName,
  int restId,
  String restImage,
  int restRating,
  LatLng restLocation,
}) =>
    serializers.toFirestore(
        RestuarantsRecord.serializer,
        RestuarantsRecord((r) => r
          ..restName = restName
          ..restId = restId
          ..restImage = restImage
          ..restRating = restRating
          ..restLocation = restLocation));

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'restuarants_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<RestuarantsRecord> _$restuarantsRecordSerializer =
    new _$RestuarantsRecordSerializer();

class _$RestuarantsRecordSerializer
    implements StructuredSerializer<RestuarantsRecord> {
  @override
  final Iterable<Type> types = const [RestuarantsRecord, _$RestuarantsRecord];
  @override
  final String wireName = 'RestuarantsRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, RestuarantsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.restName;
    if (value != null) {
      result
        ..add('rest_name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.restId;
    if (value != null) {
      result
        ..add('rest_id')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.restImage;
    if (value != null) {
      result
        ..add('rest_image')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.restRating;
    if (value != null) {
      result
        ..add('rest_rating')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.restLocation;
    if (value != null) {
      result
        ..add('rest_location')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(LatLng)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  RestuarantsRecord deserialize(
      Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new RestuarantsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'rest_name':
          result.restName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'rest_id':
          result.restId = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'rest_image':
          result.restImage = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'rest_rating':
          result.restRating = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'rest_location':
          result.restLocation = serializers.deserialize(value,
              specifiedType: const FullType(LatLng)) as LatLng;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$RestuarantsRecord extends RestuarantsRecord {
  @override
  final String restName;
  @override
  final int restId;
  @override
  final String restImage;
  @override
  final int restRating;
  @override
  final LatLng restLocation;
  @override
  final DocumentReference<Object> reference;

  factory _$RestuarantsRecord(
          [void Function(RestuarantsRecordBuilder) updates]) =>
      (new RestuarantsRecordBuilder()..update(updates)).build();

  _$RestuarantsRecord._(
      {this.restName,
      this.restId,
      this.restImage,
      this.restRating,
      this.restLocation,
      this.reference})
      : super._();

  @override
  RestuarantsRecord rebuild(void Function(RestuarantsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  RestuarantsRecordBuilder toBuilder() =>
      new RestuarantsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is RestuarantsRecord &&
        restName == other.restName &&
        restId == other.restId &&
        restImage == other.restImage &&
        restRating == other.restRating &&
        restLocation == other.restLocation &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc($jc($jc(0, restName.hashCode), restId.hashCode),
                    restImage.hashCode),
                restRating.hashCode),
            restLocation.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('RestuarantsRecord')
          ..add('restName', restName)
          ..add('restId', restId)
          ..add('restImage', restImage)
          ..add('restRating', restRating)
          ..add('restLocation', restLocation)
          ..add('reference', reference))
        .toString();
  }
}

class RestuarantsRecordBuilder
    implements Builder<RestuarantsRecord, RestuarantsRecordBuilder> {
  _$RestuarantsRecord _$v;

  String _restName;
  String get restName => _$this._restName;
  set restName(String restName) => _$this._restName = restName;

  int _restId;
  int get restId => _$this._restId;
  set restId(int restId) => _$this._restId = restId;

  String _restImage;
  String get restImage => _$this._restImage;
  set restImage(String restImage) => _$this._restImage = restImage;

  int _restRating;
  int get restRating => _$this._restRating;
  set restRating(int restRating) => _$this._restRating = restRating;

  LatLng _restLocation;
  LatLng get restLocation => _$this._restLocation;
  set restLocation(LatLng restLocation) => _$this._restLocation = restLocation;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  RestuarantsRecordBuilder() {
    RestuarantsRecord._initializeBuilder(this);
  }

  RestuarantsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _restName = $v.restName;
      _restId = $v.restId;
      _restImage = $v.restImage;
      _restRating = $v.restRating;
      _restLocation = $v.restLocation;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(RestuarantsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$RestuarantsRecord;
  }

  @override
  void update(void Function(RestuarantsRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$RestuarantsRecord build() {
    final _$result = _$v ??
        new _$RestuarantsRecord._(
            restName: restName,
            restId: restId,
            restImage: restImage,
            restRating: restRating,
            restLocation: restLocation,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new

import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'hotels_record.g.dart';

abstract class HotelsRecord
    implements Built<HotelsRecord, HotelsRecordBuilder> {
  static Serializer<HotelsRecord> get serializer => _$hotelsRecordSerializer;

  @nullable
  @BuiltValueField(wireName: 'hotel_id')
  int get hotelId;

  @nullable
  int get price;

  @nullable
  int get rating;

  @nullable
  @BuiltValueField(wireName: 'hotel_name')
  String get hotelName;

  @nullable
  @BuiltValueField(wireName: 'hotel_location')
  LatLng get hotelLocation;

  @nullable
  String get photo;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(HotelsRecordBuilder builder) => builder
    ..hotelId = 0
    ..price = 0
    ..rating = 0
    ..hotelName = ''
    ..photo = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('hotels');

  static Stream<HotelsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<HotelsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  HotelsRecord._();
  factory HotelsRecord([void Function(HotelsRecordBuilder) updates]) =
      _$HotelsRecord;

  static HotelsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createHotelsRecordData({
  int hotelId,
  int price,
  int rating,
  String hotelName,
  LatLng hotelLocation,
  String photo,
}) =>
    serializers.toFirestore(
        HotelsRecord.serializer,
        HotelsRecord((h) => h
          ..hotelId = hotelId
          ..price = price
          ..rating = rating
          ..hotelName = hotelName
          ..hotelLocation = hotelLocation
          ..photo = photo));

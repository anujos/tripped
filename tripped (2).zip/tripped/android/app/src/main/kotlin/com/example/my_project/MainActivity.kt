package com.mytripped

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
